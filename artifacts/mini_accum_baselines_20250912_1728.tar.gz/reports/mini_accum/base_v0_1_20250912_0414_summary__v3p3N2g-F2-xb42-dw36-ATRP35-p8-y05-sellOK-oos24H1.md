# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0414

## KPIs
- **net_btc_ratio**: 0.6611341887089215
- **mdd_model_usd**: 0.2839450798754306
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 1.262398854570632
- **flips_total**: 20
- **flips_blocked_hard**: 0
- **flips_per_year**: 40.583333333333336
