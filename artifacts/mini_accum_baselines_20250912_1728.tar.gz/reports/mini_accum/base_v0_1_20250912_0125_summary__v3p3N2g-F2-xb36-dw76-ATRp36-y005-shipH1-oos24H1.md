# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0125

## KPIs
- **net_btc_ratio**: 0.6827925522545535
- **mdd_model_usd**: 0.2107816926619258
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 0.9371198384476694
- **flips_total**: 26
- **flips_blocked_hard**: 0
- **flips_per_year**: 52.75833333333333
