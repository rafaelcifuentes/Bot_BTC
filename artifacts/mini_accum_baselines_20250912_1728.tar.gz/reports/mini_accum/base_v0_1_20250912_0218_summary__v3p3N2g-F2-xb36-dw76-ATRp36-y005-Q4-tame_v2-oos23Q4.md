# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0218

## KPIs
- **net_btc_ratio**: 0.8633181783942094
- **mdd_model_usd**: 0.07281504397979222
- **mdd_hodl_usd**: 0.07781619361155956
- **mdd_vs_hodl_ratio**: 0.9357312482189514
- **flips_total**: 8
- **flips_blocked_hard**: 0
- **flips_per_year**: 32.46666666666667
