# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0149

## KPIs
- **net_btc_ratio**: 0.7822628583326264
- **mdd_model_usd**: 0.10131724955176635
- **mdd_hodl_usd**: 0.07781619361155956
- **mdd_vs_hodl_ratio**: 1.3020072667331768
- **flips_total**: 16
- **flips_blocked_hard**: 0
- **flips_per_year**: 64.93333333333334
