# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250911_2341

## KPIs
- **net_btc_ratio**: 0.8530039222134748
- **mdd_model_usd**: 0.11377707371061108
- **mdd_hodl_usd**: 0.07781619361155956
- **mdd_vs_hodl_ratio**: 1.4621259204550652
- **flips_total**: 8
- **flips_blocked_hard**: 0
- **flips_per_year**: 32.46666666666667
