# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0228

## KPIs
- **net_btc_ratio**: 0.8677169559551513
- **mdd_model_usd**: 0.058560502606623155
- **mdd_hodl_usd**: 0.07781619361155956
- **mdd_vs_hodl_ratio**: 0.7525490503807426
- **flips_total**: 10
- **flips_blocked_hard**: 0
- **flips_per_year**: 40.583333333333336
