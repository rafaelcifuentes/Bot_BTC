# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0212

## KPIs
- **net_btc_ratio**: 1.1221375013093564
- **mdd_model_usd**: 0.172220188803049
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 0.7656782402226766
- **flips_total**: 8
- **flips_blocked_hard**: 0
- **flips_per_year**: 16.233333333333334
