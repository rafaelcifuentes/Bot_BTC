# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0411

## KPIs
- **net_btc_ratio**: 0.8436738381460174
- **mdd_model_usd**: 0.07856778180592816
- **mdd_hodl_usd**: 0.07781619361155956
- **mdd_vs_hodl_ratio**: 1.0096585062759604
- **flips_total**: 8
- **flips_blocked_hard**: 0
- **flips_per_year**: 32.46666666666667
