# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250911_2128

## KPIs
- **net_btc_ratio**: 1.0442625096504734
- **mdd_model_usd**: 0.16506199862960658
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 0.7338534553744345
- **flips_total**: 12
- **flips_blocked_hard**: 0
- **flips_per_year**: 24.35
