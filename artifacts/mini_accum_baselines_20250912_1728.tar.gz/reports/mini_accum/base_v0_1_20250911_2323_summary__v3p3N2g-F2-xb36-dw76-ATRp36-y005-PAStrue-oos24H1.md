# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250911_2323

## KPIs
- **net_btc_ratio**: 0.69627065704178
- **mdd_model_usd**: 0.1691572801152449
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 0.7520607744055732
- **flips_total**: 26
- **flips_blocked_hard**: 402
- **flips_per_year**: 52.75833333333333
