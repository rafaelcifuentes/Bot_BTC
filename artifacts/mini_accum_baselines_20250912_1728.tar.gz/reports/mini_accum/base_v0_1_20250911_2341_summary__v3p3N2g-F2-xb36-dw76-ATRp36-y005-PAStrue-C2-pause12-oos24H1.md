# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250911_2341

## KPIs
- **net_btc_ratio**: 1.0001265853859314
- **mdd_model_usd**: 0.24156121462319657
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 1.0739633198884688
- **flips_total**: 16
- **flips_blocked_hard**: 0
- **flips_per_year**: 32.46666666666667
