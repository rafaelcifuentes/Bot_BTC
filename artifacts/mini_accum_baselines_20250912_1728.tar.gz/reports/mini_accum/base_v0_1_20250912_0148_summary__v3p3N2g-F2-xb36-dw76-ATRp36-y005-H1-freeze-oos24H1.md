# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0148

## KPIs
- **net_btc_ratio**: 0.8654141051993369
- **mdd_model_usd**: 0.1542434313499813
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 0.685754904246569
- **flips_total**: 12
- **flips_blocked_hard**: 0
- **flips_per_year**: 24.35
