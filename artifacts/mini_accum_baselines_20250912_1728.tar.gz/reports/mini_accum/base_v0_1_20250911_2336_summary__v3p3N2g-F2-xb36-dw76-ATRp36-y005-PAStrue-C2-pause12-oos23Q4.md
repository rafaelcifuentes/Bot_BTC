# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250911_2336

## KPIs
- **net_btc_ratio**: 0.8355107243755805
- **mdd_model_usd**: 0.0828167268479052
- **mdd_hodl_usd**: 0.07781619361155956
- **mdd_vs_hodl_ratio**: 1.0642608306094634
- **flips_total**: 20
- **flips_blocked_hard**: 0
- **flips_blocked_pause_buy**: 50
- **flips_blocked_pause_sell**: 20
- **flips_per_year**: 81.16666666666667
