# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250911_2336

## KPIs
- **net_btc_ratio**: 0.859852221168109
- **mdd_model_usd**: 0.19023880918475233
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 0.8457876956877423
- **flips_total**: 26
- **flips_blocked_hard**: 185
- **flips_blocked_pause_buy**: 68
- **flips_blocked_pause_sell**: 25
- **flips_per_year**: 52.75833333333333
