# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0936

## KPIs
- **net_btc_ratio**: 0.708973253755549
- **mdd_model_usd**: 0.2125961325023824
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 0.9451867039742163
- **flips_total**: 12
- **flips_blocked_hard**: 0
- **flips_per_year**: 24.35
