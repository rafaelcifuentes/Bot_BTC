# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0940

## KPIs
- **net_btc_ratio**: 0.6819994717438884
- **mdd_model_usd**: 0.21752060270368623
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 0.9670805347960797
- **flips_total**: 10
- **flips_blocked_hard**: 0
- **flips_per_year**: 20.291666666666668
