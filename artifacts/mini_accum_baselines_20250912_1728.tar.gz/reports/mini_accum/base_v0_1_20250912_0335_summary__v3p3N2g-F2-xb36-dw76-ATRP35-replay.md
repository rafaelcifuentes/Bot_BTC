# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0335

## KPIs
- **net_btc_ratio**: 0.8977445654102704
- **mdd_model_usd**: 0.0989762577261527
- **mdd_hodl_usd**: 0.07781619361155956
- **mdd_vs_hodl_ratio**: 1.2719236592349825
- **flips_total**: 3
- **flips_blocked_hard**: 0
- **flips_per_year**: 12.175
