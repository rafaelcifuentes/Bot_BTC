# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0228

## KPIs
- **net_btc_ratio**: 0.8154920150196251
- **mdd_model_usd**: 0.10845783290311484
- **mdd_hodl_usd**: 0.07781619361155956
- **mdd_vs_hodl_ratio**: 1.3937694439863155
- **flips_total**: 12
- **flips_blocked_hard**: 0
- **flips_per_year**: 48.7
