# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0937

## KPIs
- **net_btc_ratio**: 0.6987201674298095
- **mdd_model_usd**: 0.24000124535866985
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 1.0670278117487686
- **flips_total**: 12
- **flips_blocked_hard**: 0
- **flips_per_year**: 24.35
