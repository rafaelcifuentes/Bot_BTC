# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0144

## KPIs
- **net_btc_ratio**: 0.8187881416307243
- **mdd_model_usd**: 0.18150827628710264
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 0.8069723912118929
- **flips_total**: 26
- **flips_blocked_hard**: 0
- **flips_per_year**: 52.75833333333333
