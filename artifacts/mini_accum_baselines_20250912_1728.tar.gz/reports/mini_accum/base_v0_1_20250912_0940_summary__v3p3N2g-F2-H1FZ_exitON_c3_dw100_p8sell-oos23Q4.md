# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0940

## KPIs
- **net_btc_ratio**: 0.869482913949349
- **mdd_model_usd**: 0.07781619361155967
- **mdd_hodl_usd**: 0.07781619361155956
- **mdd_vs_hodl_ratio**: 1.0000000000000013
- **flips_total**: 4
- **flips_blocked_hard**: 0
- **flips_per_year**: 16.233333333333334
