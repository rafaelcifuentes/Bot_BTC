# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0021

## KPIs
- **net_btc_ratio**: 0.8754825594520431
- **mdd_model_usd**: 0.14412003901530046
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 0.6407470495822909
- **flips_total**: 26
- **flips_blocked_hard**: 196
- **flips_per_year**: 52.75833333333333
