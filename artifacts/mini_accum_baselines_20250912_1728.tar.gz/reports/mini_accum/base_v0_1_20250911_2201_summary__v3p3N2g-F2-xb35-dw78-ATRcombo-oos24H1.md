# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250911_2201

## KPIs
- **net_btc_ratio**: 1.0439956669566814
- **mdd_model_usd**: 0.16422584826251296
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 0.7301359925956081
- **flips_total**: 12
- **flips_blocked_hard**: 0
- **flips_per_year**: 24.35
