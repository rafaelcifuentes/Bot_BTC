# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0125

## KPIs
- **net_btc_ratio**: 0.7969761671772668
- **mdd_model_usd**: 0.08760720011532619
- **mdd_hodl_usd**: 0.07781619361155956
- **mdd_vs_hodl_ratio**: 1.1258222234904096
- **flips_total**: 16
- **flips_blocked_hard**: 0
- **flips_per_year**: 64.93333333333334
