# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250911_2249

## KPIs
- **net_btc_ratio**: 0.762732181521017
- **mdd_model_usd**: 0.090528650408218
- **mdd_hodl_usd**: 0.07781619361155956
- **mdd_vs_hodl_ratio**: 1.1633651841172814
- **flips_total**: 6
- **flips_blocked_hard**: 0
- **flips_per_year**: 24.35
