# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0125

## KPIs
- **net_btc_ratio**: 0.8009304012896277
- **mdd_model_usd**: 0.058588454346308105
- **mdd_hodl_usd**: 0.07781619361155956
- **mdd_vs_hodl_ratio**: 0.7529082524746471
- **flips_total**: 12
- **flips_blocked_hard**: 0
- **flips_per_year**: 48.7
