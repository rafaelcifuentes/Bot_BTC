# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250911_2201

## KPIs
- **net_btc_ratio**: 0.9814141930618857
- **mdd_model_usd**: 0.17074633440022569
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 0.7591255923981596
- **flips_total**: 14
- **flips_blocked_hard**: 0
- **flips_per_year**: 28.408333333333335
