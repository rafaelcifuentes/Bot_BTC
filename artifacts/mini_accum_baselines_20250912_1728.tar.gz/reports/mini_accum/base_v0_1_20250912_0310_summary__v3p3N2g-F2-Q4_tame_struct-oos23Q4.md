# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0310

## KPIs
- **net_btc_ratio**: 0.8538624158952832
- **mdd_model_usd**: 0.06997259676140877
- **mdd_hodl_usd**: 0.07781619361155956
- **mdd_vs_hodl_ratio**: 0.8992035399559093
- **flips_total**: 8
- **flips_blocked_hard**: 0
- **flips_per_year**: 32.46666666666667
