# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0134

## KPIs
- **net_btc_ratio**: 0.7875840710265841
- **mdd_model_usd**: 0.16261802391536018
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 0.7229877242928543
- **flips_total**: 12
- **flips_blocked_hard**: 0
- **flips_per_year**: 24.35
