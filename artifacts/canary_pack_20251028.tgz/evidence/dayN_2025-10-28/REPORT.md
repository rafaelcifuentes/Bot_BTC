# Canary DRYRUN — Resumen diario (UTC: 2025-10-28)

- ATTEST OK: 0
- Canarios válidos: 4  | GREEN=4  | PAUSE=0  | YELLOW=0

## Últimos 12 válidos

# `canary_live.20251028T000701Z.log`
- start EXCHANGE=binance DRYRUN=1 USD<=10 cap=0.10
- 2025-10-28T00:07:01Z [INFO] canary_live: ready (signal fresh)
- 2025-10-28T00:07:01Z [INFO] canary_live: done
- → **GREEN**

# `canary_live.20251028T010700Z.log`
- start EXCHANGE=binance DRYRUN=1 USD<=10 cap=0.10
- 2025-10-28T01:07:00Z [INFO] canary_live: ready (signal fresh)
- 2025-10-28T01:07:00Z [INFO] canary_live: done
- → **GREEN**

# `canary_live.20251028T020700Z.log`
- start EXCHANGE=binance DRYRUN=1 USD<=10 cap=0.10
- 2025-10-28T02:07:00Z [INFO] canary_live: ready (signal fresh)
- 2025-10-28T02:07:00Z [INFO] canary_live: done
- → **GREEN**

# `canary_live.20251028T030700Z.log`
- start EXCHANGE=binance DRYRUN=1 USD<=10 cap=0.10
- 2025-10-28T03:07:00Z [INFO] canary_live: ready (signal fresh)
- 2025-10-28T03:07:00Z [INFO] canary_live: done
- → **GREEN**

