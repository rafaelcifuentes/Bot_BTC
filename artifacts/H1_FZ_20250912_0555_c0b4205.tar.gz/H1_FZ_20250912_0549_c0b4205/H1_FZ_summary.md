# Mini-BOT BTC v0.1 — Resumen base_v0_1_20250912_0949

## KPIs
- **net_btc_ratio**: 1.088868978375402
- **mdd_model_usd**: 0.17739459693569748
- **mdd_hodl_usd**: 0.22492501387131425
- **mdd_vs_hodl_ratio**: 0.7886832766283157
- **flips_total**: 8
- **flips_blocked_hard**: 0
- **flips_per_year**: 16.233333333333334
