# mini-accum (paquete)
CLI: `mini-accum-backtest --config configs/mini_accum.yaml --start 2021-01-01 --end 2025-09-01`
