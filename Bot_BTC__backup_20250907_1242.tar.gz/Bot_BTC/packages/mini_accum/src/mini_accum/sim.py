from __future__ import annotations
from dataclasses import dataclass
from typing import Tuple, List
import numpy as np
import pandas as pd

def max_drawdown(series: pd.Series) -> float:
    rollmax = series.cummax()
    dd = series / rollmax - 1.0
    return float(dd.min()) * -1.0 if len(series) else 0.0

@dataclass
class TradeCosts:
    fee_bps_per_side: float
    slip_bps_per_side: float
    @property
    def rate(self) -> float:
        return (self.fee_bps_per_side + self.slip_bps_per_side) / 10_000.0


def simulate(cfg: dict, df4: pd.DataFrame, costs: TradeCosts) -> Tuple[pd.DataFrame, dict]:
    ema21 = df4['close'].ewm(span=int(cfg['signals']['ema_fast']), adjust=False).mean()
    ema55 = df4['close'].ewm(span=int(cfg['signals']['ema_slow']), adjust=False).mean()
    df = df4.copy()
    df['ema21'] = ema21
    df['ema55'] = ema55
    df['trend_up'] = df['ema21'] > df['ema55']
    df['trend_dn'] = df['ema21'] < df['ema55']

    btc = float(cfg['backtest'].get('seed_btc', 1.0)); usd = 0.0
    position = 'STABLE'
    dwell_min = int(cfg['anti_whipsaw']['dwell_bars_min_between_flips'])
    bars_since_flip = dwell_min
    hard_per_year = int(cfg['flip_budget']['hard_per_year'])
    enforce_hard = bool(cfg['flip_budget'].get('enforce_hard_yearly', True))
    flips_exec_ts: List[pd.Timestamp] = []
    flips_blocked = 0
    schedule_buy_i = None; schedule_sell_i = None; pending_exit_i = None
    out = []

    for i in range(len(df) - 2):
        row = df.iloc[i]
        executed = None
        # ejecutar órdenes
        if schedule_buy_i is not None and i == schedule_buy_i:
            price = row['open']
            if usd > 0:
                btc += (usd / price) * (1.0 - costs.rate); usd = 0.0
                position = 'BTC'; flips_exec_ts.append(row['ts']); bars_since_flip = 0; executed = 'BUY'
            schedule_buy_i = None
        if schedule_sell_i is not None and i == schedule_sell_i:
            price = row['open']
            if btc > 0:
                usd += btc * price * (1.0 - costs.rate); btc = 0.0
                position = 'STABLE'; flips_exec_ts.append(row['ts']); bars_since_flip = 0; executed = 'SELL'
            schedule_sell_i = None

        macro_green = bool(row['macro_green']); trend_up = bool(row['trend_up']); trend_dn = bool(row['trend_dn'])
        bars_since_flip += 1; can_flip = bars_since_flip >= dwell_min

        if position == 'BTC' and row['close'] < row['ema21'] and pending_exit_i is None:
            pending_exit_i = i
        if pending_exit_i is not None and i == pending_exit_i + 1:
            if row['close'] <= row['ema21'] and can_flip:
                if enforce_hard:
                    one_year_ago = row['ts'] - pd.Timedelta(days=365)
                    if sum(ts > one_year_ago for ts in flips_exec_ts) >= hard_per_year:
                        flips_blocked += 1
                    else:
                        schedule_sell_i = i + 1
                else:
                    schedule_sell_i = i + 1
            pending_exit_i = None

        if position == 'BTC' and trend_dn and can_flip and schedule_sell_i is None:
            if enforce_hard:
                one_year_ago = row['ts'] - pd.Timedelta(days=365)
                if sum(ts > one_year_ago for ts in flips_exec_ts) >= hard_per_year:
                    flips_blocked += 1
                else:
                    schedule_sell_i = i + 1
            else:
                schedule_sell_i = i + 1

        if position == 'STABLE' and macro_green and trend_up and can_flip and schedule_buy_i is None:
            if enforce_hard:
                one_year_ago = row['ts'] - pd.Timedelta(days=365)
                if sum(ts > one_year_ago for ts in flips_exec_ts) >= hard_per_year:
                    flips_blocked += 1
                else:
                    schedule_buy_i = i + 1
            else:
                schedule_buy_i = i + 1

        price_now = row['close']
        equity_btc = btc + (usd / price_now if price_now > 0 else 0.0)
        equity_usd = btc * price_now + usd
        out.append({'ts': row['ts'], 'close': price_now, 'equity_btc': equity_btc,
                    'equity_usd': equity_usd, 'executed': executed})

    res = pd.DataFrame(out)
    hodl_usd = res['close'] * 1.0
    mdd_model_usd = max_drawdown(res['equity_usd'])
    mdd_hodl_usd = max_drawdown(hodl_usd)
    mdd_ratio = (mdd_model_usd / mdd_hodl_usd) if mdd_hodl_usd > 0 else np.nan
    total_days = (res['ts'].iloc[-1] - res['ts'].iloc[0]).days if len(res) else 0
    years = total_days / 365.25 if total_days > 0 else np.nan
    flips_total = len([x for x in res['executed'] if isinstance(x, str)])
    flips_per_year = flips_total / years if years and years > 0 else np.nan
    net_btc_ratio = res['equity_btc'].iloc[-1] / 1.0 if len(res) else np.nan

    kpis = {
        'net_btc_ratio': float(net_btc_ratio) if net_btc_ratio == net_btc_ratio else None,
        'mdd_model_usd': float(mdd_model_usd),
        'mdd_hodl_usd': float(mdd_hodl_usd),
        'mdd_vs_hodl_ratio': float(mdd_ratio) if mdd_ratio == mdd_ratio else None,
        'flips_total': int(flips_total),
        'flips_per_year': float(flips_per_year) if flips_per_year == flips_per_year else None,
    }
    return res, kpis
