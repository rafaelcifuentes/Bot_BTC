# Bot_BTC Monorepo

Mini‑BOT BTC (mini_accum) en paquete aislado.
